package com.my.newproject3;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class Quiz1Activity extends Activity {
	
	
	private double ques = 0;
	private double ans = 0;
	private double score = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView textview1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private Button button1;
	private CheckBox checkbox1;
	private TextView textview3;
	private CheckBox checkbox3;
	private TextView textview4;
	private CheckBox checkbox4;
	private TextView textview5;
	private CheckBox checkbox5;
	private TextView textview6;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private Button button2;
	private TextView textview7;
	private TextView textview8;
	private TextView textview9;
	
	private Intent intent = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.quiz1);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		button1 = (Button) findViewById(R.id.button1);
		checkbox1 = (CheckBox) findViewById(R.id.checkbox1);
		textview3 = (TextView) findViewById(R.id.textview3);
		checkbox3 = (CheckBox) findViewById(R.id.checkbox3);
		textview4 = (TextView) findViewById(R.id.textview4);
		checkbox4 = (CheckBox) findViewById(R.id.checkbox4);
		textview5 = (TextView) findViewById(R.id.textview5);
		checkbox5 = (CheckBox) findViewById(R.id.checkbox5);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		button2 = (Button) findViewById(R.id.button2);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textview1.setEnabled(false);
				linear3.setVisibility(View.VISIBLE);
				_Questions();
				_Answers();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (checkbox1.isChecked()) {
					if (ans == 1) {
						score++;
					}
					ques++;
					checkbox1.setChecked(false);
					_Questions();
					_Answers();
				}
				if (checkbox3.isChecked()) {
					if (ans == 2) {
						score++;
					}
					ques++;
					checkbox3.setChecked(false);
					_Questions();
					_Answers();
				}
				if (checkbox4.isChecked()) {
					if (ans == 3) {
						score++;
					}
					ques++;
					checkbox4.setChecked(false);
					_Questions();
					_Answers();
				}
				if (checkbox5.isChecked()) {
					if (ans == 4) {
						score++;
					}
					ques++;
					checkbox5.setChecked(false);
					_Questions();
					_Answers();
				}
			}
		});
		
		checkbox1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
			}
		});
		
		checkbox3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
			}
		});
		
		checkbox4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox3.setChecked(false);
				checkbox5.setChecked(false);
			}
		});
		
		checkbox5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), MainActivity.class);
				startActivity(intent);
			}
		});
	}
	private void initializeLogic() {
		_Start();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Start () {
		ques = 1;
		score = 0;
		textview1.setEnabled(true);
		textview1.setText("Click here to start the Quiz");
		linear2.setVisibility(View.VISIBLE);
		linear3.setVisibility(View.GONE);
		linear4.setVisibility(View.GONE);
	}
	
	
	private void _Questions () {
		if (ques == 1) {
			textview1.setText("What is your mother tongue?");
			textview3.setText("English");
			textview4.setText("Tamil");
			textview5.setText("Telugu");
			textview6.setText("Kannada");
		}
		if (ques == 2) {
			textview1.setText("What is 35 + 10 ?");
			textview3.setText("10");
			textview4.setText("67");
			textview5.setText("45");
			textview6.setText("90");
		}
		if (ques == 3) {
			textview1.setText("What is the capital of UK?");
			textview3.setText("Chicago");
			textview4.setText("Venice");
			textview5.setText("New Delhi");
			textview6.setText("London");
		}
		if (ques == 4) {
			textview1.setText("What is the name of the current US President?");
			textview3.setText("Barrack Obama");
			textview4.setText("Bill Clinton");
			textview5.setText("Donald Trump");
			textview6.setText("Mahatma Gandhi");
		}
		if (ques == 5) {
			linear2.setVisibility(View.GONE);
			linear3.setVisibility(View.GONE);
			linear4.setVisibility(View.VISIBLE);
			textview7.setText("Your score is:".concat(String.valueOf((long)(score))));
		}
	}
	
	
	private void _Answers () {
		if (ques == 1) {
			ans = 2;
		}
		if (ques == 2) {
			ans = 3;
		}
		if (ques == 3) {
			ans = 4;
		}
		if (ques == 4) {
			ans = 3;
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
